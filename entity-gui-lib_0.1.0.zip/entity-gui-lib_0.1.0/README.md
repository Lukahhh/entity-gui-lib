# Entity GUI Library

A Factorio 2.0 library mod that provides barebones entity GUIs for mod authors to extend. Automatically replaces vanilla entity GUIs with customizable frames that include entity preview, status display, and a content area for your custom controls.

## Features

### Core
- Proper vanilla-styled frame with titlebar and close button
- Entity preview and status display (35+ status types supported)
- Automatically intercepts and replaces vanilla entity GUIs
- Clean API via remote interface
- Supports both entity name and entity type registration

### Keyboard Support
- E key closes GUI (matches vanilla behavior)
- Escape key closes GUI

### Multi-Mod Support
- Priority system for handling conflicts between mods
- Check existing registrations before registering
- Per-mod unregister support

### Helpers
- Tabbed interface helper
- Confirmation dialog helper
- GUI refresh without closing (for live data)
- Debug mode for logging registrations and events

## Installation

Add `entity-gui-lib` as a dependency in your mod's `info.json`:

```json
{
  "dependencies": ["entity-gui-lib"]
}
```

## Usage

### Basic Registration

Register your custom GUI by providing your mod name and callback function names:

```lua
-- Define your remote interface with callback functions
remote.add_interface("my_mod", {
    build_my_gui = function(container, entity, player)
        container.add{
            type = "label",
            caption = "Hello from my custom GUI!",
        }

        container.add{
            type = "button",
            name = "my_button",
            caption = "Click me",
        }
    end,

    close_my_gui = function(entity, player)
        -- Optional: called when GUI closes
        player.print("GUI closed")
    end,
})

-- Register with the library
local function register_guis()
    remote.call("entity_gui_lib", "register", {
        mod_name = "my_mod",                    -- Your mod's remote interface name
        entity_name = "my-custom-entity",       -- Specific entity name
        -- OR entity_type = "inserter",         -- All entities of this type
        title = "My Custom GUI",                -- Optional: custom title
        on_build = "build_my_gui",              -- Callback function name
        on_close = "close_my_gui",              -- Optional: close callback name
    })
end

script.on_init(register_guis)
script.on_load(register_guis)
```

### Registration Config

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `mod_name` | string | Yes | Your mod's remote interface name |
| `entity_name` | string | One of these | Specific entity name to replace |
| `entity_type` | string | required | Entity type to replace (e.g., "inserter", "container") |
| `title` | LocalisedString | No | Custom title (defaults to entity name) |
| `on_build` | string | Yes | Name of callback function in your remote interface |
| `on_close` | string | No | Name of close callback function |
| `on_update` | string | No | Name of update callback for auto-refresh |
| `update_interval` | number | No | Ticks between updates (default: 10, ~6 times/sec) |
| `priority` | number | No | Priority for conflict resolution (default: 0, higher wins) |
| `preview_size` | number | No | Size of entity preview in pixels (default: 148) |

### Callback Signatures

**on_build**: `function(container, entity, player)`
- `container`: LuaGuiElement - Flow element to add your GUI children to
- `entity`: LuaEntity - The entity the GUI was opened for
- `player`: LuaPlayer - The player who opened the GUI

**on_close**: `function(entity, player)`
- `entity`: LuaEntity - The entity (may be invalid if destroyed)
- `player`: LuaPlayer - The player who closed the GUI

**on_update**: `function(content, entity, player)`
- `content`: LuaGuiElement - The content container (same as on_build)
- `entity`: LuaEntity - The entity the GUI is showing
- `player`: LuaPlayer - The player viewing the GUI

### Auto-Refresh Example

For live-updating GUIs (progress bars, energy levels, etc.), use `on_update`:

```lua
remote.add_interface("my_mod", {
    build_drill_gui = function(container, entity, player)
        container.add{
            type = "progressbar",
            name = "my_progress",
            value = entity.mining_progress or 0,
        }
    end,

    update_drill_gui = function(content, entity, player)
        -- Find and update the progress bar
        for _, child in pairs(content.children) do
            if child.name == "my_progress" then
                child.value = entity.mining_progress or 0
            end
        end
    end,
})

remote.call("entity_gui_lib", "register", {
    mod_name = "my_mod",
    entity_type = "mining-drill",
    on_build = "build_drill_gui",
    on_update = "update_drill_gui",
    update_interval = 10,  -- Update every 10 ticks
})
```

### Multiple Registrations & Priority

When multiple mods register for the same entity, the highest priority wins:

```lua
-- Mod A registers with default priority (0)
remote.call("entity_gui_lib", "register", {
    mod_name = "mod_a",
    entity_type = "inserter",
    on_build = "build_inserter_gui",
})

-- Mod B registers with higher priority - this one will be used
remote.call("entity_gui_lib", "register", {
    mod_name = "mod_b",
    entity_type = "inserter",
    on_build = "build_inserter_gui",
    priority = 100,
})
```

Check existing registrations before registering:

```lua
local existing = remote.call("entity_gui_lib", "get_registrations", "inserter")
for _, reg in ipairs(existing) do
    log("Mod " .. reg.mod_name .. " registered with priority " .. reg.priority)
end
```

## Remote Interface Functions

### Core Functions

```lua
-- Register an entity GUI
remote.call("entity_gui_lib", "register", config)

-- Unregister an entity GUI (all mods)
remote.call("entity_gui_lib", "unregister", "entity-name-or-type")

-- Unregister only your mod's registration
remote.call("entity_gui_lib", "unregister", "entity-name-or-type", "your_mod_name")

-- Get all registrations for an entity (for conflict checking)
local registrations = remote.call("entity_gui_lib", "get_registrations", "entity-name-or-type")

-- Get the content container for a player's open GUI
local container = remote.call("entity_gui_lib", "get_content", player_index)

-- Get the entity for a player's open GUI
local entity = remote.call("entity_gui_lib", "get_entity", player_index)

-- Refresh/rebuild GUI content without closing (useful for live data)
local success = remote.call("entity_gui_lib", "refresh", player_index)

-- Close a player's GUI programmatically
remote.call("entity_gui_lib", "close", player_index)
```

### Helper Functions

#### Tabbed Interface

```lua
-- In your on_build callback:
local tabbed_pane, tab_contents = remote.call("entity_gui_lib", "create_tabs", container, {
    {name = "info", caption = "Info"},
    {name = "settings", caption = "Settings"},
})

-- Add content to each tab
tab_contents.info.add{type = "label", caption = "Info tab content"}
tab_contents.settings.add{type = "label", caption = "Settings tab content"}
```

#### Confirmation Dialog

```lua
-- Add callbacks to your remote interface
remote.add_interface("my_mod", {
    show_delete = function(player_index, entity_data)
        remote.call("entity_gui_lib", "show_confirmation", player_index, {
            mod_name = "my_mod",
            title = "Confirm Delete",
            message = "Are you sure you want to delete this?",
            confirm_caption = "Delete",      -- optional, defaults to "Confirm"
            cancel_caption = "Keep",         -- optional, defaults to "Cancel"
            on_confirm = "do_delete",
            on_cancel = "cancel_delete",     -- optional
            data = entity_data,              -- passed to callbacks
        })
    end,

    do_delete = function(player, data)
        player.print("Deleted!")
    end,

    cancel_delete = function(player, data)
        player.print("Cancelled")
    end,
})
```

### Debug Mode

Enable debug logging to see registrations and GUI events in the Factorio log:

```lua
-- Enable debug mode
remote.call("entity_gui_lib", "set_debug_mode", true)

-- Check if debug mode is enabled
local enabled = remote.call("entity_gui_lib", "is_debug_mode")
```

Log output appears in `factorio-current.log`:
- Windows: `%APPDATA%\Factorio\factorio-current.log`
- Linux: `~/.factorio/factorio-current.log`
- macOS: `~/Library/Application Support/factorio/factorio-current.log`

Example log output:
```
[entity-gui-lib] Registered: inserter by my_mod (priority: 0)
[entity-gui-lib] Opened GUI for inserter (player: PlayerName, mod: my_mod)
```

## Handling GUI Events

Handle button clicks and other GUI events in your mod:

```lua
script.on_event(defines.events.on_gui_click, function(event)
    local element = event.element
    if not element or not element.valid then return end

    if element.name == "my_button" then
        local entity = remote.call("entity_gui_lib", "get_entity", event.player_index)
        if entity and entity.valid then
            -- Do something with the entity
        end
    end
end)
```

## Example

See the `examples/entity-gui-lib-example` folder for a complete working example that demonstrates:
- Custom inserter GUI with rotation button
- Custom assembling machine GUI with recipe display
- Custom container GUI with inventory display

## License

MIT
