-- Custom input for closing entity GUI with E key
data:extend({
    {
        type = "custom-input",
        name = "entity-gui-lib-toggle",
        key_sequence = "",
        linked_game_control = "toggle-menu",
    },
})
